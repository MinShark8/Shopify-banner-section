Demo: https://demo-elements.myshopify.com/?view=banner (PASS=1)
